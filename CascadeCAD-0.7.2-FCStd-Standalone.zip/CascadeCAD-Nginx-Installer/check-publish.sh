#!/usr/bin/env bash
set -euo pipefail
URL=${1:-}
[[ -n "$URL" ]] || { echo "Usage: $0 https://example.com/CascadeCAD/" >&2; exit 2; }
echo '=== nginx syntax ==='
sudo nginx -t
echo '=== URL headers ==='
curl -sSIL --max-time 30 "$URL"
echo '=== local service ==='
curl -fsS --max-time 15 http://127.0.0.1:8790/cascade-cad/healthz 2>/dev/null || \
  curl -fsS --max-time 15 http://127.0.0.1:8790/healthz
