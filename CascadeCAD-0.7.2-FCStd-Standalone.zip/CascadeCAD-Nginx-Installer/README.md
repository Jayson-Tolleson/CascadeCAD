# CascadeCAD Complete Standalone Installer

This ZIP now contains the **full CascadeCAD 0.7.1 Large-Model application** and the Nginx publishing installer. It can install or upgrade CascadeCAD and publish it in one command.

## Contents

- `CascadeCAD/` — complete application source and production installer
- `install-standalone.sh` — installs CascadeCAD, then configures Nginx
- `install-nginx.sh` — configures only Nginx
- `check-publish.sh` — publishing checks
- `uninstall-nginx-routing.sh` — removes only the CascadeCAD Nginx route

Project data under `/var/lib/cascade-cad` and an existing `/etc/cascade-cad.env` are preserved by the application upgrade process.

## Existing website subpath

```bash
unzip CascadeCAD-Complete-Standalone.zip
cd CascadeCAD-Nginx-Installer

sudo bash install-standalone.sh \
  --domain example.com \
  --mode subpath \
  --path /CascadeCAD \
  --max-upload 5g
```

Publishes:

```text
https://example.com/CascadeCAD/
```

The installer detects the existing Nginx virtual host, backs it up, creates a separate CascadeCAD snippet, and inserts only an `include` directive. Existing website routes and TLS configuration are preserved.

## Dedicated domain

```bash
sudo bash install-standalone.sh \
  --domain cad.example.com \
  --mode domain \
  --max-upload 5g \
  --tls \
  --email admin@example.com
```

Publishes:

```text
https://cad.example.com/
```

DNS must already point to the server before requesting the certificate.

## Application-only installation

```bash
sudo bash install-standalone.sh --app-only
```

## Nginx-only update

```bash
sudo bash install-standalone.sh \
  --nginx-only \
  --domain example.com \
  --mode subpath \
  --path /CascadeCAD \
  --max-upload 5g
```

## Large-upload behavior

The previous Nginx-only package used a 20 MB request limit. This package defaults to **5 GB**, configurable with `--max-upload`:

```bash
--max-upload 2g
--max-upload 5g
--max-upload 10g
```

Uploads are streamed to CascadeCAD with Nginx request buffering disabled. Confirm that the server has enough disk space for the upload, working copy, revisions, XBF, and GLB preview.

## Included protections

- Full bundled CascadeCAD application
- 5,000,000-triangle faceted conversion ceiling
- Nginx configuration backup before changes
- `nginx -t` validation before reload
- WebSocket routing for collaboration
- Streaming uploads without proxy request buffering
- Configurable large-file upload ceiling
- One-hour static caching with revalidation
- One-hour proxy read/send timeouts
- Optional Certbot/Let's Encrypt configuration
- Automatic `CASCADE_CAD_BASE_PATH` synchronization
- Existing project-data preservation

### FCStd support

The embedded CascadeCAD application is version 0.7.2 and includes native exact
FreeCAD `.FCStd` import through the installed `freecad-python3` console worker.
FCStd uploads bypass the mesh scene reader.
