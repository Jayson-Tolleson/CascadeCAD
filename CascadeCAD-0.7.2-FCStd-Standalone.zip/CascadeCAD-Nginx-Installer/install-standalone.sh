#!/usr/bin/env bash
set -euo pipefail

if [[ $EUID -ne 0 ]]; then
  echo "Run with sudo: sudo bash install-standalone.sh [options]" >&2
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
INSTALL_APP=1
APP_ONLY=0
NGINX_ARGS=()

usage() {
  cat <<'USAGE'
CascadeCAD complete standalone installer

Installs the bundled CascadeCAD application and then publishes it through Nginx.

Examples:
  sudo bash install-standalone.sh --domain cad.example.com --mode domain --tls --email admin@example.com
  sudo bash install-standalone.sh --domain example.com --mode subpath --path /CascadeCAD

Standalone options:
  --nginx-only       Do not reinstall/upgrade the bundled CascadeCAD application
  --app-only         Install/upgrade CascadeCAD, but do not configure Nginx
  -h, --help         Show this help and the Nginx publishing options

Nginx options passed through include:
  --domain NAME
  --mode domain|subpath
  --path /CascadeCAD
  --upstream 127.0.0.1:8790
  --max-upload 5g
  --tls --email ADDRESS
USAGE
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --nginx-only)
      INSTALL_APP=0
      shift
      ;;
    --app-only)
      APP_ONLY=1
      shift
      ;;
    -h|--help)
      usage
      echo
      bash "$SCRIPT_DIR/install-nginx.sh" --help
      exit 0
      ;;
    *)
      NGINX_ARGS+=("$1")
      shift
      ;;
  esac
done

if [[ $INSTALL_APP -eq 1 ]]; then
  echo "Installing/upgrading the bundled CascadeCAD application..."
  bash "$SCRIPT_DIR/CascadeCAD/install.sh"
fi

if [[ $APP_ONLY -eq 1 ]]; then
  echo "CascadeCAD application installation complete; Nginx configuration skipped."
  exit 0
fi

if [[ ${#NGINX_ARGS[@]} -eq 0 ]]; then
  echo "Nginx publishing options are required unless --app-only is used." >&2
  usage >&2
  exit 2
fi

bash "$SCRIPT_DIR/install-nginx.sh" "${NGINX_ARGS[@]}"
