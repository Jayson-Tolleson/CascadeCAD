#!/usr/bin/env bash
set -euo pipefail
[[ $EUID -eq 0 ]] || { echo 'Run with sudo' >&2; exit 1; }
echo "This removes only CascadeCAD-specific standalone site files and snippets."
rm -f /etc/nginx/sites-enabled/cascadecad-*.conf
rm -f /etc/nginx/sites-available/cascadecad-*.conf
rm -f /etc/nginx/snippets/cascadecad-*.conf
nginx -t && systemctl reload nginx
echo "Review any existing vhost where an include line may have been merged; backups are under /etc/nginx/cascadecad-backup-*"
