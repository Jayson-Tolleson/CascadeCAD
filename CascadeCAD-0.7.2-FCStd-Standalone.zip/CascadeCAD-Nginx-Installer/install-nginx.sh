#!/usr/bin/env bash
set -euo pipefail

if [[ $EUID -ne 0 ]]; then
  echo "Run with sudo: sudo bash install-nginx.sh [options]" >&2
  exit 1
fi

DOMAIN=""
MODE="subpath"
BASE_PATH="/CascadeCAD"
UPSTREAM="127.0.0.1:8790"
EMAIL=""
ENABLE_TLS=0
SITE_ROOT="/var/www/html"
MAX_UPLOAD="5g"

usage() {
  cat <<USAGE
CascadeCAD standalone Nginx publisher

Usage:
  sudo bash install-nginx.sh --domain cad.example.com --mode domain [--tls --email you@example.com]
  sudo bash install-nginx.sh --domain example.com --mode subpath --path /CascadeCAD [--tls --email you@example.com]

Options:
  --domain NAME       Public domain name (required)
  --mode MODE         domain or subpath (default: subpath)
  --path PATH         Public path for subpath mode (default: /CascadeCAD)
  --upstream HOST:PORT CascadeCAD Hypercorn upstream (default: 127.0.0.1:8790)
  --tls               Install certbot and request/attach a Let's Encrypt certificate
  --email ADDRESS     Email for Let's Encrypt registration
  --site-root PATH    Existing website root (informational; default: /var/www/html)
  --max-upload SIZE   Maximum CAD upload accepted by Nginx (default: 5g)
  -h, --help          Show help
USAGE
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --domain) DOMAIN=${2:?}; shift 2 ;;
    --mode) MODE=${2:?}; shift 2 ;;
    --path) BASE_PATH=${2:?}; shift 2 ;;
    --upstream) UPSTREAM=${2:?}; shift 2 ;;
    --tls) ENABLE_TLS=1; shift ;;
    --email) EMAIL=${2:?}; shift 2 ;;
    --site-root) SITE_ROOT=${2:?}; shift 2 ;;
    --max-upload) MAX_UPLOAD=${2:?}; shift 2 ;;
    -h|--help) usage; exit 0 ;;
    *) echo "Unknown option: $1" >&2; usage; exit 2 ;;
  esac
done

[[ -n "$DOMAIN" ]] || { echo "--domain is required" >&2; usage; exit 2; }
[[ "$MODE" == domain || "$MODE" == subpath ]] || { echo "--mode must be domain or subpath" >&2; exit 2; }
BASE_PATH="/${BASE_PATH#/}"
BASE_PATH="${BASE_PATH%/}"
[[ "$BASE_PATH" != "/" ]] || BASE_PATH="/CascadeCAD"

apt-get update
apt-get install -y nginx curl ca-certificates

BACKUP_DIR="/etc/nginx/cascadecad-backup-$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP_DIR"
cp -a /etc/nginx/nginx.conf /etc/nginx/sites-available /etc/nginx/sites-enabled "$BACKUP_DIR/" 2>/dev/null || true

install -d -m 0755 /etc/nginx/snippets /etc/nginx/sites-available /etc/nginx/sites-enabled

if [[ "$MODE" == "domain" ]]; then
  BASE_PATH=""
  ENV_BASE_PATH=""
  SITE_FILE="/etc/nginx/sites-available/cascadecad-${DOMAIN//[^A-Za-z0-9_.-]/_}.conf"
  cat > "$SITE_FILE" <<CONF
server {
    listen 80;
    listen [::]:80;
    server_name $DOMAIN;

    client_max_body_size $MAX_UPLOAD;
    client_body_timeout 3600s;
    send_timeout 3600s;

    location /ws/ {
        proxy_pass http://$UPSTREAM;
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_buffering off;
        proxy_read_timeout 3600s;
        proxy_send_timeout 3600s;
    }

    location / {
        proxy_pass http://$UPSTREAM;
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_set_header Connection "";
        proxy_request_buffering off;
        proxy_buffering off;
        proxy_read_timeout 3600s;
        proxy_send_timeout 3600s;
    }

    location ~* \\.(?:js|css|png|jpg|jpeg|gif|svg|ico|woff2?)$ {
        proxy_pass http://$UPSTREAM;
        proxy_set_header Host \$host;
        proxy_set_header X-Forwarded-Proto \$scheme;
        expires 1h;
        add_header Cache-Control "public, must-revalidate";
    }
}
CONF
  ln -sfn "$SITE_FILE" "/etc/nginx/sites-enabled/$(basename "$SITE_FILE")"
else
  ENV_BASE_PATH="$BASE_PATH"
  SNIPPET="/etc/nginx/snippets/cascadecad-${DOMAIN//[^A-Za-z0-9_.-]/_}.conf"
  cat > "$SNIPPET" <<CONF
# CascadeCAD at https://$DOMAIN$BASE_PATH
location = $BASE_PATH { return 308 $BASE_PATH/; }

location ^~ $BASE_PATH/ws/ {
    proxy_pass http://$UPSTREAM;
    proxy_http_version 1.1;
    proxy_connect_timeout 30s;
    proxy_set_header Host \$host;
    proxy_set_header X-Real-IP \$remote_addr;
    proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto \$scheme;
    proxy_set_header X-Forwarded-Host \$host;
    proxy_set_header X-Forwarded-Prefix $BASE_PATH;
    proxy_set_header Upgrade \$http_upgrade;
    proxy_set_header Connection "upgrade";
    proxy_buffering off;
    proxy_read_timeout 3600s;
    proxy_send_timeout 3600s;
}

location ^~ $BASE_PATH/ {
    client_max_body_size $MAX_UPLOAD;
    client_body_timeout 3600s;
    send_timeout 3600s;
    proxy_pass http://$UPSTREAM;
    proxy_http_version 1.1;
    proxy_connect_timeout 30s;
    proxy_set_header Host \$host;
    proxy_set_header X-Real-IP \$remote_addr;
    proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto \$scheme;
    proxy_set_header X-Forwarded-Host \$host;
    proxy_set_header X-Forwarded-Prefix $BASE_PATH;
    proxy_set_header Connection "";
    proxy_request_buffering off;
    proxy_buffering off;
    proxy_read_timeout 3600s;
    proxy_send_timeout 3600s;
}
CONF

  # Safely add include to an existing matching vhost when one is detectable.
  MATCH=$(grep -RIlE "server_name[[:space:]]+([^;[:space:]]+[[:space:]]+)*${DOMAIN//./\\.}([[:space:];])" /etc/nginx/sites-available 2>/dev/null | head -1 || true)
  if [[ -n "$MATCH" ]]; then
    cp -a "$MATCH" "$BACKUP_DIR/$(basename "$MATCH").before-cascadecad"
    if ! grep -Fq "include $SNIPPET;" "$MATCH"; then
      # Insert before the final closing brace, preserving the existing site and TLS settings.
      python3 - "$MATCH" "$SNIPPET" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1]); snippet=sys.argv[2]
s=p.read_text()
pos=s.rfind('}')
if pos < 0: raise SystemExit('No closing server brace found')
s=s[:pos] + f'    include {snippet};\n' + s[pos:]
p.write_text(s)
PY
    fi
    echo "Merged CascadeCAD include into $MATCH"
  else
    EXAMPLE="/etc/nginx/sites-available/cascadecad-${DOMAIN//[^A-Za-z0-9_.-]/_}-merge-example.conf"
    cat > "$EXAMPLE" <<CONF
# No existing vhost for $DOMAIN was detected.
# Add this line inside the correct server { } block, then enable/reload nginx:
# include $SNIPPET;
CONF
    echo "No existing $DOMAIN vhost detected. Add: include $SNIPPET;"
  fi
fi

# Keep CascadeCAD's application base path synchronized with Nginx.
ENV_FILE=/etc/cascade-cad.env
if [[ -f "$ENV_FILE" ]]; then
  if grep -q '^CASCADE_CAD_BASE_PATH=' "$ENV_FILE"; then
    sed -i "s#^CASCADE_CAD_BASE_PATH=.*#CASCADE_CAD_BASE_PATH=$ENV_BASE_PATH#" "$ENV_FILE"
  else
    printf '\nCASCADE_CAD_BASE_PATH=%s\n' "$ENV_BASE_PATH" >> "$ENV_FILE"
  fi
fi

nginx -t
systemctl enable --now nginx
systemctl reload nginx
if systemctl list-unit-files | grep -q '^cascade-cad.service'; then
  systemctl restart cascade-cad cascade-cad-worker 2>/dev/null || systemctl restart cascade-cad 2>/dev/null || true
fi

if [[ $ENABLE_TLS -eq 1 ]]; then
  [[ -n "$EMAIL" ]] || { echo "--email is required with --tls" >&2; exit 2; }
  apt-get install -y certbot python3-certbot-nginx
  certbot --nginx --non-interactive --agree-tos --redirect --email "$EMAIL" -d "$DOMAIN"
fi

SCHEME=http
[[ $ENABLE_TLS -eq 1 ]] && SCHEME=https
PUBLIC_PATH="$BASE_PATH/"
[[ "$MODE" == domain ]] && PUBLIC_PATH=/

echo
echo "CascadeCAD Nginx publishing installed."
echo "Public URL: $SCHEME://$DOMAIN$PUBLIC_PATH"
echo "Upstream:   http://$UPSTREAM"
echo "Max upload: $MAX_UPLOAD"
echo "Backup:     $BACKUP_DIR"
echo
echo "Checks:"
echo "  sudo nginx -t"
echo "  curl -I $SCHEME://$DOMAIN$PUBLIC_PATH"
echo "  sudo journalctl -u nginx -u cascade-cad -n 100 --no-pager"
