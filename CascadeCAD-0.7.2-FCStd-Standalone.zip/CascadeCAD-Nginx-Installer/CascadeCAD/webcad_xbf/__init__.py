"""CascadeCAD Quart application backed by Open CASCADE."""

__version__ = "0.7.2"
