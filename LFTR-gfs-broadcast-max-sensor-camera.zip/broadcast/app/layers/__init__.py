"""LFTR visual layer contracts."""
